# Introduction to neural-networks

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
