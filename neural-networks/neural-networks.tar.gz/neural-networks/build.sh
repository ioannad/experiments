#!/bin/bash

lein uberjar
