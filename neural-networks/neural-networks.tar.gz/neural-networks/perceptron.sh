#!/bin/bash

java -jar target/uberjar/neural-networks-0.1.0-SNAPSHOT-standalone.jar
